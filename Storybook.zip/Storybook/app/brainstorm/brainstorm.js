function handleGoBack(){
    window.location.replace('../editor/editor.html')
}