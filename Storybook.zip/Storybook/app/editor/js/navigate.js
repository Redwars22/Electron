function handleNavigate(path){
    if(path == 'settings')
        window.location.replace('../settings/settings.html');

    if(path == 'brainstorm')
        window.location.replace('../brainstorm/brainstorm.html');

    // if(path == '')
    //     window.location.replace('');

    // if(path == '')
    //     window.location.replace('');

    // if(path == '')
    //     window.location.replace('');
}